from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/')
def main():
    return render_template('calculator.html')


@app.route('/send', methods=['POST'])
def send(otvet=sum):
    if request.method == 'POST':
        firstNumber = request.form['firstNumber']
        secondNumber = request.form['secondNumber']
        operation = request.form['operation']

        if operation == 'Сложение':
            sum = round(float(firstNumber) + float(secondNumber),3)
            return render_template('calculator.html', otvet=sum)

        elif operation == 'Вычитание':
            sum = round(float(firstNumber) - float(secondNumber),3)
            return render_template('calculator.html', otvet=sum)

        elif operation == 'Умножение':
            sum = round(float(firstNumber) * float(secondNumber),3)
            return render_template('calculator.html', otvet=sum)

        elif operation == 'Деление':
            sum = round(float(firstNumber) / float(secondNumber), 3)
            return render_template('calculator.html', otvet=sum)

        elif operation == 'Возведение в степень':
            sum = round(float(firstNumber) ** float(secondNumber),3)
            return render_template('calculator.html', otvet=sum)

        elif operation == 'Квадратный корень':
            sum = round(float(firstNumber)**.5,3)
            return render_template('calculator.html', otvet=sum)
        else:
            return render_template('calculator.html')


if __name__ == ' __main__':
    app.debug = True
    app.run()
